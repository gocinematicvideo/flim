<?php

return [
    'movies'         => 'Filme artistice',
    'popular'        => 'Populare',
    'now_playing'    => 'Difuzate acum',
    'top_rated'      => 'Cele mai mari evaluări',
    'upcoming'       => 'Pe viitor',
    'tv_shows'       => 'Filme Seriale',
    'on_tv'          => 'La televizor',
    'airing_today'   => 'Difuzate astăzi',
    'genres'         => 'Genuri',
    'popular_people' => 'Persoane populare',
    'search'         => 'Căutare...',
];


