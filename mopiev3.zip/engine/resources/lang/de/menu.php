<?php

return [
    'movies'         => 'Filme',
    'popular'        => 'Beliebt',
    'now_playing'    => 'Läuft gerade',
    'top_rated'      => 'Bestbewertet',
    'upcoming'       => 'Bevorstehende',
    'tv_shows'       => 'Fernsehshows',
    'on_tv'          => 'Es gibt einen Fernseher',
    'airing_today'   => 'Heute lüften',
    'genres'         => 'Genres',
    'popular_people' => 'Beliebte Leute',
    'search'         => 'Suche...',
];
