<?php

return [
    'previous' => '&laquo; Poprzednia',
    'next'     => 'Następna &raquo;',
];
