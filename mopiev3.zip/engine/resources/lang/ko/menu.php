<?php

return [
    'movies'         => '영화',
    'popular'        => '인기',
    'now_playing'    => '현재 상영 중',
    'top_rated'      => '높은 평점',
    'upcoming'       => '개봉 예정',
    'tv_shows'       => 'TV 프로그램',
    'on_tv'          => 'TV 방영 중',
    'airing_today'   => '오늘 방영',
    'genres'         => '장르',
    'popular_people' => '인기있는 사람들',
    'search'         => '수색...',
];


