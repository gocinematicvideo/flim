<?php

return [
    'previous' => '&laquo; Назад',
    'next'     => 'Напред &raquo;',
];
