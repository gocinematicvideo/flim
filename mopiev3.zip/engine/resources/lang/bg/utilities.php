<?php

return [
    'view_all'        => 'View All',
    'subscribe_watch' => 'Абонирайте се за Гледайте | $0.00',
    'released'        => 'Освободен',
    'runtime'         => 'Времетраене',
    'genre'           => 'Жанр',
    'stars'           => 'Звезди',
    'director'        => 'Режисьор',
    'minutes'         => 'минути',
    'by'              => 'от',
    'users'           => 'потребители',
    'download'        => 'Изтегли',
    'season'          => 'Сезон',
    'watch'           => 'Гледам',
    'episode'         => 'Епизод',
    'movies'          => 'кино',
    'know_for'        => 'Известен за',
    'birthday'        => 'Рожден ден',
    'place_of_birth'  => 'Място на раждане',
    'also_know_as'    => 'Известен също като',
    'biography'       => 'биография',
    'sign_in'         => 'Впиши се',
    'register'        => 'Регистрирам',

    'watch_now'       => 'Гледай сега'
];
