<?php

return [
    'active_your_account_free' => 'Aktiválja INGYENES fiókját!',
    'you_must_create'          => 'A figyelés folytatásához létre kell hoznia egy fiókot',
    'continue_watch'           => 'Nézze tovább INGYEN ➞',
    'quick_sign_up'            => 'Gyors feliratkozás!',
    'take_less_then'           => 'Kevesebb, mint 1 percig tart a regisztráció, majd élvezheti a Korlátlan Filmek és TV címeket.',
];
