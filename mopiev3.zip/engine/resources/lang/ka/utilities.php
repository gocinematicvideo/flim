<?php

return [
    'view_all'        => 'იხილეთ ყველა',
    'subscribe_watch' => 'გამოწერა თვალს | $0.00',
    'released'        => 'გამოვიდა',
    'runtime'         => 'ხანგრძლივობა',
    'genre'           => 'ჟანრი',
    'stars'           => 'ვარსკვლავები',
    'director'        => 'ვარსკვლავები',
    'minutes'         => 'წუთი',
    'by'              => 'მიერ',
    'users'           => 'მომხმარებლები',
    'download'        => 'ჩამოტვირთვა',
    'season'          => 'სეზონი',
    'watch'           => 'თვალს',
    'episode'         => 'ეპიზოდი',
    'movies'          => 'ფილმები',
    'know_for'        => 'ცნობილია',
    'birthday'        => 'დაბადების დღე',
    'place_of_birth'  => 'დაბადების ადგილი',
    'also_know_as'    => 'ასევე ცნობილია',
    'biography'       => 'ბიოგრაფია',
    'sign_in'         => 'შესვლა',
    'register'        => 'რეგისტრაცია',

    'watch_now'       => 'ნახეთ ახლა',
];
