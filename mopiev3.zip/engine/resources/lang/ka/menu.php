<?php

return [
    'movies'         => 'ფილმები',
    'popular'        => 'პოპულარული',
    'now_playing'    => 'ახლა',
    'top_rated'      => 'საუკეთესო',
    'upcoming'       => 'მალე',
    'tv_shows'       => 'სერიალები',
    'on_tv'          => 'ტელევიზორში',
    'airing_today'   => 'დღეს ტვ-ში',
    'genres'         => 'ჟანრები',
    'popular_people' => 'სახელგანთქმულები',
    'search'         => 'ძიება...',
];

