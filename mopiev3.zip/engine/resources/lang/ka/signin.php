<?php

return [
    'sign_in'             => 'Sign In',
    'email'               => 'ელ.ფოსტა',
    'password'            => 'პაროლი',
    'well_never_share'    => 'ჩვენ ვერასდროს გაგიზიარებთ თქვენს ელფოსტას.',
    'forgot_password'     => 'Forgot Password?',
    'or'                  => 'ან',
    'create_free_account' => 'შექმენით უფასო ანგარიში',

    'enter_email'      => 'შეიყვანეთ ელ.ფოსტა',
    'reset_password'   => 'პაროლის აღდგენა',
    'enter_your_email' => 'შეიყვანეთ თქვენი ელექტრონული ფოსტის მისამართი და ჩვენ გამოგიგზავნით ბმულს თქვენი პაროლის გადატვირთვისთვის.',
    'back_to_sign_in'  => 'შესვლა შესვლა',
    'loading'          => 'Wait...',
];
