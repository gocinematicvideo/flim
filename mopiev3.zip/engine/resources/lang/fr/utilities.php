<?php

return [
    'view_all'        => 'Voir Tous Les',
    'subscribe_watch' => 'Abonnez-vous Pour Regarder | €0.00',
    'released'        => 'Sortie',
    'runtime'         => 'Durée',
    'genre'           => 'Genre',
    'stars'           => 'Etoiles',
    'director'        => 'Directeur',
    'minutes'         => 'minutes',
    'by'              => 'de',
    'users'           => 'utilisateurs',
    'download'        => 'Télécharger',
    'season'          => 'Saison',
    'watch'           => 'Regarder',
    'episode'         => 'Episode',
    'movies'          => 'Films',
    'know_for'        => 'Connu Pour',
    'birthday'        => 'Anniversaire',
    'place_of_birth'  => 'Lieu de Naissance',
    'also_know_as'    => 'Aussi Connu Comme',
    'biography'       => 'Biographie',
    'sign_in'         => 'Se Connecter',
    'register'        => 'Registre',

    'watch_now'       => 'Regarde maintenant',
];
