<?php

return [
    'previous' => '&laquo; Forrige',
    'next'     => 'Næste &raquo;',
];
