<?php

return [
    'active_your_account_free' => 'Aktivér din GRATIS konto!',
    'you_must_create'          => 'Du skal oprette en konto for at fortsætte med at se',
    'continue_watch'           => 'Fortsæt med at se GRATIS ➞',
    'quick_sign_up'            => 'Hurtig tilmelding!',
    'take_less_then'           => 'Det tager mindre end 1 minut at tilmelde dig, så kan du nyde ubegrænset film og tv-titler.',
];
