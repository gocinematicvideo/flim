<?php

return [
    'previous' => '&laquo; Trang sau',
    'next'     => 'Trang trước &raquo;',
];
