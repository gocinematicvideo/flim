<?php

return [
    'movies'         => 'Filmler',
    'popular'        => 'Popüler',
    'now_playing'    => 'Gösterimde',
    'top_rated'      => 'En Fazla Oy Alanlar',
    'upcoming'       => 'Gelecek',
    'tv_shows'       => 'Diziler',
    'on_tv'          => 'Televizyonda',
    'airing_today'   => 'Günün Programı',
    'genres'         => 'Türler',
    'popular_people' => 'Popüler İnsanlar',
    'search'         => 'Arama...',
];
