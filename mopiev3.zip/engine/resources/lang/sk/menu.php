<?php

return [
    'movies'         => 'Filmy',
    'popular'        => 'Populárne',
    'now_playing'    => 'Teraz hrané',
    'top_rated'      => 'Najlepšie hodnotené',
    'upcoming'       => 'Nadchádzajúce',
    'tv_shows'       => 'Seriály',
    'on_tv'          => 'Teraz vysielané',
    'airing_today'   => 'Vysielané dnes',
    'genres'         => 'Žánre',
    'popular_people' => 'Populárne Osoby',
    'search'         => 'Vyhľadávanie...',
];


