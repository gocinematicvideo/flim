<?php

return [
    'home_title'       => 'Filmy bez televízneho vysielania a televízne programy',
    'home_description' => 'Prehliadajte a sledujte všetky svoje obľúbené online filmy a seriály zadarmo!',

    'movie_title' => 'Pozerajte :title Celý film online zadarmo',
    'tv_title'    => 'Sledujte bezplatné televízne relácie :title HD',
];
