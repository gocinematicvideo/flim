<?php

return [
    'active_your_account_free' => 'Aktivujte si svoj bezplatný účet!',
    'you_must_create'          => 'Ak chcete pokračovať v sledovaní, musíte si vytvoriť účet',
    'continue_watch'           => 'Naďalej sledujte ZADARMO ➞',
    'quick_sign_up'            => 'Rýchle prihlásenie!',
    'take_less_then'           => 'Registrácia trvá menej ako 1 minútu a potom si môžete vychutnať neobmedzený počet filmov a titulov v televízii.',
];
