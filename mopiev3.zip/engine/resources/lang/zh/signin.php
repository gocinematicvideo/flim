<?php

return [
    'sign_in'             => '登入',
    'email'               => '电子邮件',
    'password'            => '密码',
    'well_never_share'    => '我们绝不会与其他任何人分享您的电子邮件。',
    'forgot_password'     => '忘记密码？',
    'or'                  => '要么',
    'create_free_account' => '创建免费帐户',

    'enter_email'      => '输入邮箱',
    'reset_password'   => '重设密码',
    'enter_your_email' => '输入您的电子邮件地址，我们会向您发送重置密码的链接。',
    'back_to_sign_in'  => '回到登录',
    'loading'          => '载入中...',
];
