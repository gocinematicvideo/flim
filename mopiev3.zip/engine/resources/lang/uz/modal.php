<?php

return [
    'active_your_account_free' => 'BEPUL hisobingizni faollashtiring!',
    'you_must_create'          => 'Tomosha qilishni davom ettirish uchun siz hisob yaratishingiz kerak',
    'continue_watch'           => 'BEPUL watch tomoshasini davom ettiring ➞',
    'quick_sign_up'            => 'Tez ro\'yxatdan o\'ting!',
    'take_less_then'           => 'Ro\'yhatdan o\'tish 1 daqiqadan kam vaqtni oladi, keyin siz Cheksiz Filmlar va TV sarlavhalaridan bahramand bo\'lishingiz mumkin.',
];
