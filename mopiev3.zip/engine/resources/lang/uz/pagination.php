<?php

return [
    'previous' => '&lsaquo; Oldingi',
    'next'     => 'Keyingi &rsaquo;'
];
