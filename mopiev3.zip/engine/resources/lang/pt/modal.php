<?php

return [
    'active_your_account_free' => 'Ative sua conta GRATUITA!',
    'you_must_create'          => 'Você deve criar uma conta para continuar assistindo',
    'continue_watch'           => 'Continue a assistir gratuitamente ➞',
    'quick_sign_up'            => 'Registo Rápido!',
    'take_less_then'           => 'Demora menos de 1 minuto para se inscrever, então você pode desfrutar de filmes ilimitados e títulos de TV.',
];
