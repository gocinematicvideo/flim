<?php

return [
    'api_key' => '892b7c8469f251441be840cf2aeb9d74',
    'tmdb_debug' => false,
    'theme' => 'v1',
    'is_cache' => true,
    'cache_exp' => 1440,

    'url_offer_default' => 'https://www.google.com/search?q=mopie.xyz%20landing%20page%20movie%20tv%20shows&sub_id=default',
    'url_offer_sub_id' => 'https://www.google.com/search?q=mopie.xyz%20landing%20page%20movie%20tv%20shows&sub_id=',
	
	'export_button_watch' => 'https://www.google.com/search?q=mopie.xyz%20landing%20page%20movie%20tv%20shows',
	'export_button_download' => 'https://www.google.com/search?q=mopie.xyz%20landing%20page%20movie%20tv%20shows',

    'block_movie' => [],
    'block_tv' => [],

    'max_limit_page_sitemap' => 5,
];
